
# Leemos un número entero por teclado
numero = int(input("Introduce un número entero: "))
## Función esPrimo que evaluará  si el entero es o no primo
def esPrimo(numero):
   if numero <= 1: #// Si es 1 o menor, directamente no será primo
      return False
   else:
     # Si es mayor, realizo la comprobación
      for i in range(2, numero):
         if numero % i == 0:
            return False
      return True

# Imprimimos el resultado de lo evaluado:
if(esPrimo(numero)):
      print("El número :", numero,"SI es primo")
else:
      print("El número :", numero,"NO es primo")
  
   
