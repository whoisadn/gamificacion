
#include <iostream>
using namespace std;

bool esPrimo(int); // Invocamos la función
int main(int argc, char** argv)
{
    // Leemos el número
    cout << "Introduce un numero entero:" << endl;
    int numero;
    cin >> numero;
    // Imprimimos lo evaluado
    if(esPrimo(numero)) {
        cout << "El numero : " << numero << " SI es primo"<< endl;
    } else {
        cout << "El numero : " << numero << " NO es primo" << endl;
        return 0;
    }
}
// Función para ver si es o no primo
bool esPrimo(int numero)
{

    if(numero <= 1) { // Si es 1 o menor, directamente no será primo
        return false;
    } else { // Si es mayor, evaluamos el número
        for(int i = 2; i <= numero / 2; i++) {
            if((numero % i) == 0) {
                return false;
            }
            return true;
        }
    }
}
