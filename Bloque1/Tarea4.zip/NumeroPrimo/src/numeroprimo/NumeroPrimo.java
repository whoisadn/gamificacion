
package numeroprimo;

import java.util.Scanner;


public class NumeroPrimo {

  
    public static void main(String[] args) {
        // Leemos un número entero por teclado
    Scanner sc = new Scanner(System.in);
    System.out.println("Introduce un número entero:");
    int numero;
    numero = sc.nextInt();
 //Imprimimos el resultado de lo evaluado:
    if(esPrimo(numero)){
			System.out.println("El número:"+ numero+" SI  es primo");
    }else{
			System.out.println("El número:"+ numero+" NO es primo");
	}
    }
    // Función esPrimo que evaluará  si el entero es o no primo
    static boolean esPrimo(int numero){
	
		if(numero <= 1){ // Si es 1 o menor, directamente no será primo
			return false;
                } else { // Si es mayor, realizo la comprobación
                    for(int i=2; i<= numero/2; i++){
                            if((numero % i) == 0)
                                    return false;
                    }
                    return true;
                }    
	}
 }

