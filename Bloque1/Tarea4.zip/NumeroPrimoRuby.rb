#Leemos el número
puts "Introduce un número entero: "
  numero = gets
  numero = numero.to_i
#Función para comprobar si es o no primo
def esPrimo(numero)
  es_Primo = true
  if numero < 2
      es_Primo = false
  end
  for i in 2..numero-1
    if numero % i == 0
      es_Primo = false
    end
  end
  if es_Primo
    puts "El número: #{numero} SI es primo"
  else
    puts "El número: #{numero} NO es primo."
  end
end

#Llamada a la función
esPrimo(numero)